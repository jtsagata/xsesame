Some test files to test the code

Also serves as a test for filtering
